.. click:: ape_compile._cli:cli
  :prog: compile
  :nested: full
