# ape.contracts

```{eval-rst}
.. autoclass:: ape.contracts.base.ContractInstance
    :members:
    :show-inheritance:
    :special-members:
    :exclude-members: __repr__, __weakref__, __metaclass__
```

```{eval-rst}
.. autoclass:: ape.contracts.base.ContractContainer
    :members:
    :show-inheritance:
    :special-members:
    :exclude-members: __repr__, __weakref__, __metaclass__, __call__
```

