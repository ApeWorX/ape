import click

click.launch("https://en.wikipedia.org/wiki/Killing_of_Harambe")
